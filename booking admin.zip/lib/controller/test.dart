void main() {
  print("ali salhab");
  List data = [
    {
      "rates_id": "8",
      "rates_hotelid": "37",
      "rates_startdate": "2023-12-21",
      "rates_enddate": "2023-12-21",
      "rates_availability": "12",
      "rates_group": "flutter web ",
      "rates_mealplan": "break fast ",
      "rates_roomid": "37",
      "rates_value": "12"
    },
    {
      "rates_id": "8",
      "rates_hotelid": "37",
      "rates_startdate": "2023-12-21",
      "rates_enddate": "2023-12-21",
      "rates_availability": "12",
      "rates_group": "flutter web ",
      "rates_mealplan": "break fast ",
      "rates_roomid": "37",
      "rates_value": "12"
    }
  ];
  for (int i = 0; i < data.length; i++) {
    print(data[i]);
  }
}
