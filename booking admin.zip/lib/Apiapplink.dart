class ApiApplinks {
  static const server = "https://alisalhabqq11.000webhostapp.com/";
  static const roomimagesfolder = server + "upload/roomimages/";
  static const profilesimagefolder = server + "upload/usersprofileimages/";
  static const String forgetpassword =
      server + "forgetpassword/forgetpassword.php";
  static const String resetpassword =
      server + "forgetpassword/resetpassword.php";
  static const String verifycodeforget =
      server + "forgetpassword/verifycode.php";
  // auth
  static const String login = server + "customer/auth/login.php";
  static const String signup = server + "customer/auth/signup.php";
  static const String verifycode = server + "customer/auth/verifycode.php";
  static const String getrooms = server + "customer/Home/viewrooms.php";
  static const String getroomphoto =
      server + "customer/Home/getroomsimages.php";
}
// addhotel/hotelphotosview.php
// https://alisalhabqq11.000webhostapp.com/auth/login.php
// rooms/add.php