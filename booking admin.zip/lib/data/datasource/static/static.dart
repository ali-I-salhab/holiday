import 'package:get/get.dart';

import '../../../core/constants/imageassets.dart';
import '../../model/onboardingmodel.dart';

List<OnboardingModel> onboardinglist = [
  OnboardingModel(
      title: "Follow excursion activities",
      body: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed",
      images: ImageAssets.onboardingone),
  OnboardingModel(
      title: "Get ready for the best trips",
      body: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed ",
      images: ImageAssets.onboardingtwo),
  OnboardingModel(
      title: "Follow excursion activities",
      body: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed",
      images: ImageAssets.onboardingthree),
];
