class OnboardingModel {
  final String? title;
  final String? images;

  final String? body;
  OnboardingModel({this.title, this.body, this.images});
}
//