// ignore: non_constant_identifier_names
enum Statusrequest {
  none,
  loading,
  success,
  serverfailure,
  offlinefailure,
  failure,
  serverexception
}
